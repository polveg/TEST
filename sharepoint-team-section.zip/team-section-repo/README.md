# SharePoint Team Section

A lightweight, interactive team section built for **SharePoint** (Embed web part). Zero dependencies -- a single HTML file with inline CSS and JS.

![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=javascript&logoColor=black)
![SharePoint](https://img.shields.io/badge/SharePoint-0078D4?style=flat&logo=microsoftsharepoint&logoColor=white)
![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)

---

## Features

- **6 team member cards** in a responsive 3-column grid
- **Profile pictures** with automatic initials fallback when no image is provided
- **Send Mail** button per card (opens default email client)
- **Hover animations** -- card lift, avatar scale, button highlight
- **Staggered entrance** -- cards fade in sequentially on page load
- **Responsive** -- adapts to 2-column (tablet) and 1-column (mobile) layouts
- **No dependencies** -- vanilla HTML, CSS, and JS in a single file
- **SharePoint-ready** -- uses Segoe UI font, compatible with the Embed web part

---

## Preview

| Desktop (3 columns) | Mobile (1 column) |
|---|---|
| Cards with photo / initials, name, role, and mail button | Stacked single-column layout |

> Open `index.html` locally in any browser to preview.

---

## Quick Start

### Option A -- SharePoint Embed

1. Open your SharePoint page in **Edit** mode.
2. Add a new web part and choose **Embed**.
3. Copy the full contents of [`index.html`](index.html) and paste into the embed code editor.
4. Publish the page.

### Option B -- GitHub Pages

1. Fork or clone this repository.
2. Enable **GitHub Pages** in repository Settings (source: `main` branch, root `/`).
3. Your team section is live at `https://<your-username>.github.io/<repo-name>/`.

### Option C -- Local Preview

```bash
git clone https://github.com/<your-username>/sharepoint-team-section.git
cd sharepoint-team-section
open index.html
```

---

## Customization

All team data lives in a single `team` array inside `index.html`. Open the file and edit the JavaScript block near line **200**:

```js
const team = [
  {
    name:  "Alexandra Chen",
    role:  "Chief Technology Officer",
    email: "alexandra.chen@company.com",
    photo: ""  // URL to photo, or "" for auto-initials
  },
  // ... more members
];
```

### Field Reference

| Field   | Type   | Description |
|---------|--------|-------------|
| `name`  | string | Display name shown on the card |
| `role`  | string | Job title displayed below the name |
| `email` | string | Email address for the **Send Mail** button |
| `photo` | string | Image URL. Leave `""` for auto-generated initials avatar |

### Photo Paths

| Environment | Example Path |
|-------------|-------------|
| SharePoint  | `/sites/yoursite/SiteAssets/photos/person.jpg` |
| Relative    | `./photos/person.jpg` |
| External    | `https://example.com/photos/person.jpg` |

### Adding or Removing Members

Add or remove objects from the `team` array. The grid adapts automatically. For best visual balance, use **3** or **6** members (fills complete rows in the 3-column layout).

### Changing Colors

All colors are defined as CSS custom properties at the top of the `<style>` block:

```css
:root {
  --sap-blue:       #1B90FF;
  --dark-navy:      #002A86;
  --deep-navy:      #00144A;
  --hyperlink-blue: #0070F2;
  --light-blue:     #89D1FF;
  --light-sky:      #D1EFFF;
  --white:          #FFFFFF;
  --black:          #000000;
  --light-gray:     #EAECEE;
  --dark-gray:      #666666;
  --medium-gray:    #999999;
}
```

Override any variable to match your brand.

---

## Project Structure

```
sharepoint-team-section/
├── index.html          # The complete team section (HTML + CSS + JS)
├── README.md           # This file
├── LICENSE             # MIT License
├── CONTRIBUTING.md     # Contribution guidelines
└── .gitignore          # Git ignore rules
```

---

## Browser Support

| Browser | Supported |
|---------|-----------|
| Chrome  | Yes |
| Edge    | Yes |
| Firefox | Yes |
| Safari  | Yes |
| IE 11   | No  |

---

## License

This project is licensed under the [MIT License](LICENSE).

---

## Contributing

Contributions are welcome. Please read [CONTRIBUTING.md](CONTRIBUTING.md) before submitting a pull request.
