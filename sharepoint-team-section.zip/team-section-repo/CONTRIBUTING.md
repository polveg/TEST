# Contributing

Thank you for your interest in contributing to this project. Please follow the guidelines below.

## How to Contribute

1. **Fork** the repository.
2. **Create a branch** for your change:
   ```bash
   git checkout -b feature/your-feature-name
   ```
3. **Make your changes** in `index.html`.
4. **Test locally** by opening `index.html` in a browser and verifying:
   - Cards render correctly for all team members.
   - Hover animations work.
   - Mail buttons open the correct `mailto:` link.
   - Layout is responsive at desktop, tablet, and mobile widths.
5. **Commit** with a clear message:
   ```bash
   git commit -m "Add: description of change"
   ```
6. **Push** and open a **Pull Request** against `main`.

## Guidelines

- Keep it as a single `index.html` file -- no external dependencies.
- Preserve SharePoint Embed compatibility (inline styles and scripts only).
- Test in Chrome, Edge, Firefox, and Safari before submitting.
- Follow existing code style and formatting.

## Reporting Issues

Open an [Issue](../../issues) with:
- A clear title describing the problem.
- Steps to reproduce.
- Expected vs. actual behavior.
- Browser and OS information.
